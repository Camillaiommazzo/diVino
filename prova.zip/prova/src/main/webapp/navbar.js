const bottone = document.querySelector(".media");
const nav = document.querySelector(".nav");

bottone.addEventListener("click", ()=> {nav.classList.toggle("mediaNav");})
