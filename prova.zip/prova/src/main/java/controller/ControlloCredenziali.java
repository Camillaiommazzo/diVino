package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Utente;
import model.UtenteDAO;

import java.io.IOException;

@WebServlet(name = "ControlloCredenziali", value = "/ControlloCredenziali")
public class ControlloCredenziali extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String resp="/index.jsp";
        String username = request.getParameter("nome_utente");
        String password = request.getParameter("password");
        UtenteDAO u = new UtenteDAO();
        Utente utente = u.doRetrieveByUsernamePassword(username, password);
        HttpSession session = request.getSession();

        if(utente==null)
        {
            resp="Login.jsp";
        }
        else
            session.setAttribute("utenteSessione",utente);
        response.sendRedirect("index.jsp");

    }



    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
