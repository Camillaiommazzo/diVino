package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Prodotto;
import model.ProdottoDAO;

import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "MostraNegozio", value = "/MostraNegozio")
public class MostraNegozio extends HttpServlet {
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ProdottoDAO prodottoDAO = new ProdottoDAO();
        ArrayList<Prodotto> prodotto = (ArrayList<Prodotto>) prodottoDAO.doRetrieveAllProduct();
        request.setAttribute("listaProdotti", prodotto);
      /*  RequestDispatcher dispatcher = request.getRequestDispatcher("VisualizzaNegozio.jsp");
        dispatcher.forward(request, response); */

    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     doGet(request, response);
    }
}
