package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.Prodotto;
import model.ProdottoDAO;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "MostraProdotto", value = "/MostraProdotto")
public class MostraProdotto extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Prodotto p = new Prodotto();
        String cod = (request.getParameter("cod"));
        ProdottoDAO pDAO = new ProdottoDAO();
       p= pDAO.doRetrieveById(cod);
        request.setAttribute("prodotto", p);
      //  PrintWriter out = response.getWriter();

        RequestDispatcher dispatcher = request.getRequestDispatcher("ModificaProdotto.jsp");
        dispatcher.forward(request,response);


    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
