package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.ArrayList;

@WebServlet(name = "Checkout", value = "/Checkout")
public class Checkout extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        float prezzoTot = 0;
        int quantitaTot = 0;
        Carrello c = new Carrello();
        ArrayList<Prodotto> prodotti = (ArrayList<Prodotto>) request.getSession().getAttribute("carrello");
        Utente u = (Utente) request.getSession().getAttribute("utenteSessione");
        ArticoloCarrelloDAO aDAO = new ArticoloCarrelloDAO();
        CarrelloDao cDAO = new CarrelloDao();



        for (Prodotto p: prodotti) {
            ArticoloCarrello a = new ArticoloCarrello();
            a.setNomeUtente(u.getNomeUtente());
            a.setCodiceUtente(u.getCodice());
            a.setPrezzoUnita(p.getPrezzo());
            a.setCodProdotto(p.getCod());
           // int id = c.getCounter();
            //a.setId(id++);
            //c.setCounter(id);

            //dosave dell articolo che crea il nuovo codice
            aDAO.doSave(a);
            //doretrieve di tutti gli articoli creati
            ArrayList<ArticoloCarrello> artcolicorrenti= (ArrayList<ArticoloCarrello>) aDAO.doRetrieveAllProduct();

            //inizializzo una variabile a uno, che corrisponde all'id dell articolo appena creato(1  se è il primo
            // altrimenti verra aggiornato nel for, il quale scorre tutti gli elementi del database fino a trovare quello
            //con l id max, che sarebbe  l 'articolo appena creato

            int idcurr=1;
            for (ArticoloCarrello acurr: artcolicorrenti) {
                if(idcurr<acurr.getId())
                    idcurr=acurr.getId();
            }
            //setto l'id nel bean
            a.setId(idcurr);
            //aggiungo l'articolo completo di id al carrello
            c.getArticoli().add(a);
            quantitaTot++;
            prezzoTot+= p.getPrezzo();
        }


        c.setCodiceU(u.getCodice());
        c.setNomeU(u.getNomeUtente());
        c.setQuantita(quantitaTot);
        c.setTotale(prezzoTot);
        c.setDataC(new Date(System.currentTimeMillis()));
        /* Salvo  carrello*/


        int idcurrCarrello=0;
        ArrayList<Carrello> carrelli= (ArrayList<Carrello>) cDAO.doRetrieveByNomeUtente(u.getNomeUtente());
        for (Carrello Ccurr: carrelli) {
            if(idcurrCarrello < Ccurr.getIdC())
                idcurrCarrello= Ccurr.getIdC();
        }
        idcurrCarrello+=1;
        c.setIdC(idcurrCarrello);
        cDAO.doSave(c);

        // svuoto il carrello
        request.getSession().setAttribute("carrello",null);
        request.getSession().setAttribute("quantita", 0);
        request.getSession().setAttribute("prezzo", 0.0F);

        RequestDispatcher dispatcher = request.getRequestDispatcher("Ordini.jsp");
        dispatcher.forward(request,response);

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
