package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.Utente;
import model.UtenteDAO;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

@WebServlet(name = "ModificaUtente", value = "/ModificaUtente")
public class ModificaUtente extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Utente x = new Utente();
        UtenteDAO y = new UtenteDAO();
        x.setNomeUtente(request.getParameter("nomeUtente"));
        x.setNome(request.getParameter("nome"));
        x.setCognome(request.getParameter("cognome"));
        x.setVia(request.getParameter("via"));
        x.setPassword(request.getParameter("password"));
        x.setCitta(request.getParameter("citta"));
        x.setTelefono(request.getParameter("telefono"));
        x.setCap(Integer.parseInt(request.getParameter("CAP")));
         x.setCivico(Integer.parseInt(request.getParameter("civico")));
        y.doUpdateUserInfo(x);
        RequestDispatcher dispatcher = request.getRequestDispatcher("AreaPersonale.jsp");
        dispatcher.forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }
}
