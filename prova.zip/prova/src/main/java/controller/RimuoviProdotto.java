package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.ProdottoDAO;

import java.io.IOException;

@WebServlet(name = "RimuoviProdotto", value = "/RimuoviProdotto")
public class RimuoviProdotto extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String cod = request.getParameter("cod");
        ProdottoDAO pDAO = new ProdottoDAO();
        pDAO.doDelete(cod);
        RequestDispatcher dispatcher = request.getRequestDispatcher("Magazzino.jsp");
        dispatcher.forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
