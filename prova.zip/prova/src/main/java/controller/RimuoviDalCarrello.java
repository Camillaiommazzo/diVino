package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Prodotto;
import model.ProdottoDAO;

import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "RimuoviDalCarrello", value = "/RimuoviDalCarrello")
public class RimuoviDalCarrello extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ArrayList<Prodotto>  carrello = (ArrayList<Prodotto>) request.getSession().getAttribute("carrello");
        if(carrello!=null) {
            int quantita = (int) request.getSession().getAttribute("quantita");
            float prezzo = (float) request.getSession().getAttribute("prezzo");

            Prodotto pr = new Prodotto();
            ProdottoDAO prDAO = new ProdottoDAO();
            pr = prDAO.doRetrieveById(request.getParameter("id"));
            quantita--;
            prezzo -= pr.getPrezzo();
            int i = 0;
            for (Prodotto p : carrello) {
                if (p.getCod() == pr.getCod()) {
                    carrello.remove(i);
                    break;
                }
                i++;
            }
            if (carrello.size() == 0) {
                carrello = null;
            }
            request.getSession().setAttribute("carrello", carrello);
            request.getSession().setAttribute("quantita", quantita);
            request.getSession().setAttribute("prezzo", prezzo);
        }
        RequestDispatcher dispatcher = request.getRequestDispatcher("Carrello.jsp");
        dispatcher.forward(request, response);
    }
}
