package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Utente;
import model.UtenteDAO;

import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "Registrazione", value = "/Registrazione")
public class Registrazione extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Utente x = new Utente();
        UtenteDAO y = new UtenteDAO();
        ArrayList<Utente> utenti = (ArrayList<Utente>) y.doRetrieveAllUsers();

        for (int i = 0; i < utenti.size() ; i++) {
            if(utenti.get(i).getNomeUtente().equals(request.getParameter("nome_utente"))){
               request.setAttribute("regError",1);
                RequestDispatcher dispatcher = request.getRequestDispatcher("Registrazione.jsp");
                dispatcher.forward(request,response);
            }
        }
        request.setAttribute("regError",0);
        x.setNome(request.getParameter("nome"));
        x.setCognome(request.getParameter("cognome"));
        x.setTelefono(request.getParameter("telefono"));
        x.setVia(request.getParameter("via"));
        x.setCap(Integer.parseInt(request.getParameter("CAP")));
        x.setCitta(request.getParameter("citta"));
        x.setNomeUtente(request.getParameter("nome_utente"));
        x.setPassword(request.getParameter("password"));
         y.doSave(x);
        RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
        dispatcher.forward(request,response);
    }
}
