package model;

import com.mysql.cj.PreparedQuery;
import jakarta.servlet.RequestDispatcher;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CarrelloDao {
    public List<Prodotto> doRetrieveAllProduct() {
        List<Prodotto> list = new ArrayList<Prodotto>();
        try (Connection con = ConPool.getConnection())
        {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM carrello WHERE 1=1");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Prodotto p = new Prodotto();
                p.setCod((rs.getInt(1)));
                p.setNome(rs.getString(2));
                p.setPrezzo(rs.getFloat(3));
                p.setDescrizione(rs.getString(4));
                list.add(p);
            }
            return list;
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public List<Carrello> doRetrieveByNomeUtente(String nomeUtente) {
        List<Carrello> list = new ArrayList<Carrello>();
        try (Connection con = ConPool.getConnection())
        {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM carrello WHERE nomeU=?");
           ps.setString(1,nomeUtente);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Carrello a = new Carrello();
                a.setIdC(rs.getInt(1));
                a.setDataC(rs.getDate(2));
                a.setQuantita(rs.getInt(3));
                a.setCodiceU(rs.getInt(4));
                a.setNomeU(rs.getString(5));//non salvo gli id dei prodotti, per salvarli basta fare un for con una lista, in fine settare la lista nel carrello
                a.setTotale(rs.getFloat(7));
                list.add(a);
            }
            return list;
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public void doSave(Carrello carrello) {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO carrello ( idC,dataC,quantita ,codiceU,nomeU,id, totale) VALUES(?,?,?,?,?,?,?)"
                    //            , Statement.RETURN_GENERATED_KEYS
            );
            ps.setInt(1,carrello.getIdC());
            ps.setDate(2, (Date) carrello.getDataC());
            ps.setInt(3, carrello.getQuantita());
            ps.setInt(4, carrello.getCodiceU());
            ps.setString(5, carrello.getNomeU());
            ps.setFloat(7, carrello.getTotale());

            //setto id di articoli
            ArrayList<ArticoloCarrello> articoli = carrello.getArticoli();
            for (ArticoloCarrello a:
                   articoli) {
                ps.setInt(6, a.getId());
                if (ps.executeUpdate() != 1) {
                    throw new RuntimeException("INSERT error.");
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
