package model;

public class UtenteDAO {
}
