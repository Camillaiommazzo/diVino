package model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProdottoDAO {
    public List<Prodotto> doRetrieveAllProduct() {
        List<Prodotto> list = new ArrayList<Prodotto>();
        try (Connection con = ConPool.getConnection())
        {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM prodotto");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Prodotto p = new Prodotto();
                p.setCod((rs.getInt(1)));
                p.setNome(rs.getString(2));
                p.setPrezzo(rs.getFloat(3));
                p.setLink_immagine(rs.getString(4));
                p.setDescrizione(rs.getString(5));
                list.add(p);
            }
            return list;
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    public Prodotto doRetrieveById(String cod) {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps =
                    con.prepareStatement("SELECT cod, nome, prezzo,link_immagine, descrizione FROM prodotto WHERE cod=?");
             ps.setString(Integer.parseInt("0"), cod);
             ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Prodotto p = new Prodotto();
                p.setCod((rs.getInt(1)));
                p.setNome(rs.getString(2));
                p.setPrezzo(rs.getFloat(3));
                p.setLink_immagine(rs.getString(4));
                p.setDescrizione(rs.getString(5));
                return p;
            }
            return null;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public void doSave(Prodotto prodotto) {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO prodotto (cod, nome, prezzo,link_immagine, descrizione) VALUES(?,?,?,?,?)"
                    //            , Statement.RETURN_GENERATED_KEYS                   // questo codice è utile solo se si vuole restituire il bean customer completo di id
            );                                                            // in questo caso restituiamo  void per cui è inutile
            ps.setInt(1, (prodotto.getCod()));
            ps.setString(2, prodotto.getNome());
            ps.setFloat(3, prodotto.getPrezzo());
            ps.setString(4, prodotto.getLink_immagine());
            ps.setString(5, prodotto.getDescrizione());
            if (ps.executeUpdate() != 1) {
                throw new RuntimeException("INSERT error.");
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
        public void doDelete(String cod) {
            try(Connection con = ConPool.getConnection()) {
                PreparedStatement ps = con.prepareStatement("" +
                        "DELETE FROM prodotto WHERE cod =?", Statement.RETURN_GENERATED_KEYS);
                ps.setString(1, cod);
                if (ps.executeUpdate() != 1) {
                    throw new RuntimeException("INSERT error.");
                }
            } catch (SQLException e) {
                throw  new RuntimeException(e);
            }
        }

    public void doUpdateInfo(Prodotto temp )
    {
        try (Connection con = ConPool.getConnection())
        {
            PreparedStatement ps = con.prepareStatement("UPDATE prodotto SET nome=?,prezzo=?, " +
                            "link_immagine=?, descrizione=? WHERE cod=? ",
                    Statement.RETURN_GENERATED_KEYS);

            ps.setString(1, temp.getNome());
            ps.setFloat(2, temp.getPrezzo());
            ps.setString(3, temp.getDescrizione());
            ps.setString(4, temp.getLink_immagine());
            ps.setInt(5, temp.getCod());
            ps.executeUpdate();

        } catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
    }


    public void doUpdatePrice(Prodotto temp ) {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps = con.prepareStatement("UPDATE prodotto SET prezzo=?, " +
                            " WHERE cod=? ",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setFloat(1, temp.getPrezzo());
            ps.setInt(2, temp.getCod());
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
