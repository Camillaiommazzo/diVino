package model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class ArticoloCarrelloDAO {
    public List<Prodotto> doRetrieveAllProduct() {
        List<Prodotto> list = new ArrayList<Prodotto>();
        try (Connection con = ConPool.getConnection())
        {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM Prodotti");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Prodotto p = new Prodotto();
                p.setCod(rs.getInt(1));
                p.setNome(rs.getString(2));
                p.setPrezzo(rs.getFloat(3));
                p.setDescrizione(rs.getString(4));
                list.add(p);
            }
            return list;
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void doSave(ArticoloCarrello articolo) {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO articolocarrello (id, quantita, prezzoUnita, codiceProdotto, idC) VALUES(?,?,?,?,?)"
                    //            , Statement.RETURN_GENERATED_KEYS                   // questo codice è utile solo se si vuole restituire il bean customer completo di id
            );                                                            // in questo caso restituiamo  void per cui è inutile
            ps.setInt(1, (articolo.getId()));
            ps.setInt(2, articolo.getQuantita());
            ps.setFloat(3, articolo.getPrezzoUnita());
            ps.setInt(4, articolo.getIdC());
            if (ps.executeUpdate() != 1) {
                throw new RuntimeException("INSERT error.");
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void doDelete(int id) {
        try(Connection con = ConPool.getConnection()) {
            PreparedStatement ps = con.prepareStatement("" +
                    "DELETE FROM articolocarrello WHERE id =?", Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, id);
            if (ps.executeUpdate() != 1) {
                throw new RuntimeException("INSERT error.");
            }
        } catch (SQLException e) {
            throw  new RuntimeException(e);
        }
    }
}
