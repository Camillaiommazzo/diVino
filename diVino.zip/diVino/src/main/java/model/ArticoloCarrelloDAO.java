package model;

public class ArticoloCarrelloDAO {
}
