package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CarrelloDao {
    public List<Prodotto> doRetrieveAllProduct() {
        List<Prodotto> list = new ArrayList<Prodotto>();
        try (Connection con = ConPool.getConnection())
        {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM carrello WHERE id = codC");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Prodotto p = new Prodotto();
                p.setCod((rs.getInt(1)));
                p.setNome(rs.getString(2));
                p.setPrezzo(rs.getFloat(3));
                p.setDescrizione(rs.getString(4));
                list.add(p);
            }
            return list;
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
