package model;

public class ArticoloCarrello {

    private String codiceProdotto;
    private float prezzoUnita;
    private int quantita, id, idC;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCodiceProdotto() {
        return codiceProdotto;
    }

    public void setCodiceProdotto(String codiceProdotto) {
        this.codiceProdotto = codiceProdotto;
    }

    public int getIdC() {
        return idC;
    }

    public void setIdC(int idC) {
        this.idC = idC;
    }

    public float getPrezzoUnita() {
        return prezzoUnita;
    }

    public void setPrezzoUnita(float prezzoUnita) {
        this.prezzoUnita = prezzoUnita;
    }

    public int getQuantita() {
        return quantita;
    }

    public void setQuantita(int quantita) {
        this.quantita = quantita;
    }
}
