package model;

public class CarrelloDAO {
}
