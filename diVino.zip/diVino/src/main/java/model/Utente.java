package model;

public class Utente {
       private boolean amministratore;
    private String nome,cognome,via, nomeUtente, passwordUtente, citta,telefono;
    private int cap,civico, codice;

    public Utente(boolean amministratore, String nome, String cognome, String via, String nomeUtente, String passwordUtente, String citta, String telefono, int cap, int civico, int codice) {
        this.amministratore = amministratore;
        this.nome = nome;
        this.cognome = cognome;
        this.via = via;
        this.nomeUtente = nomeUtente;
        this.passwordUtente = passwordUtente;
        this.citta = citta;
        this.telefono = telefono;
        this.cap = cap;
        this.civico = civico;
        this.codice = codice;
    }

    public Utente()
    {}

    public String getCitta() {
        return citta;
    }
    public void setCitta(String citta) {
        this.citta = citta;
    }

    public String getPassword() {
        return passwordUtente;
    }

    public void setPassword(String password) {
        this.passwordUtente = passwordUtente;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public int getCodice() {
        return codice;
    }

    public String getNomeUtente() {
        return nomeUtente;
    }

    public void setNomeUtente(String nomeUtente) {
        this.nomeUtente = nomeUtente;
    }

    public void setCodice(int codice) {
        this.codice = codice;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCognome() {
        return cognome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public String getVia() {
        return via;
    }

    public void setVia(String via) {
        this.via = via;
    }

    public int getCap() {
        return cap;
    }

    public void setCap(int cap) {
        this.cap = cap;
    }

    public int getCivico() {
        return civico;
    }

    public void setCivico(int civico) {
        this.civico = civico;
    }

    public boolean isAmministratore() {
        return amministratore;
    }

    public void setAmministratore(boolean amministratore) {
        this.amministratore = amministratore;
    }
}
