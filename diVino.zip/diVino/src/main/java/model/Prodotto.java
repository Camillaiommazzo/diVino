package model;

public class Prodotto {
    private String nome,descrizione, link_immagine, tipo;
    private float prezzo;
    private int cod;

    public Prodotto() {
    }

    public Prodotto(String nome, String descrizione, String link_immagine, String tipo, float prezzo) {
        this.nome = nome;
        this.descrizione = descrizione;
        this.link_immagine = link_immagine;
        this.tipo = tipo;
        this.prezzo = prezzo;
    }

    public Prodotto(String nome, String descrizione, String link_immagine, String tipo, float prezzo, int cod) {
        this.nome = nome;
        this.descrizione = descrizione;
        this.link_immagine = link_immagine;
        this.tipo = tipo;
        this.prezzo = prezzo;
        this.cod = cod;
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public float getPrezzo() {
        return prezzo;
    }

    public void setPrezzo(float prezzo) {
        this.prezzo = prezzo;
    }

    public String getLink_immagine() {
        return link_immagine;
    }

    public void setLink_immagine(String link_immagine) {
        this.link_immagine = link_immagine;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
