package model;

public class Prodotto {
    private String nome,descrizione, link_immagine;
    private float prezzo;
    private int cod;

    public Prodotto(String cod, String nome, float prezzo, String descrizione, String s) {
    }

    public Prodotto() {

    }


    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public float getPrezzo() {
        return prezzo;
    }

    public void setPrezzo(float prezzo) {
        this.prezzo = prezzo;
    }

    public String getLink_immagine() {
        return link_immagine;
    }

    public void setLink_immagine(String link_immagine) {
        this.link_immagine = link_immagine;
    }
}
