package model;

import java.util.GregorianCalendar;

public class Carrello {
    private String nomeU;
    private float totale;
    private GregorianCalendar dataC;
    private int quantita, codiceU, codP;

    public String getNomeU() {
        return nomeU;
    }

    public void setNomeU(String nomeU) {
        this.nomeU = nomeU;
    }

    public float getTotale() {
        return totale;
    }

    public void setTotale(float totale) {
        this.totale = totale;
    }

    public GregorianCalendar getDataC() {
        return dataC;
    }

    public void setDataC(GregorianCalendar dataC) {
        this.dataC = dataC;
    }

    public int getQuantita() {
        return quantita;
    }

    public void setQuantita(int quantita) {
        this.quantita = quantita;
    }

    public int getCodiceU() {
        return codiceU;
    }

    public void setCodiceU(int codiceU) {
        this.codiceU = codiceU;
    }

    public int getCodP() {
        return codP;
    }

    public void setCodP(int codP) {
        this.codP = codP;
    }
}
