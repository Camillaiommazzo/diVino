package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.Prodotto;
import model.ProdottoDAO;

import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "RimuoviDalCarrello", value = "/RimuoviDalCarrello")
public class RimuoviDalCarrello extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ArrayList<Prodotto>  carrello = (ArrayList<Prodotto>) request.getSession().getAttribute("carrello");
        int quantita = (int) request.getSession().getAttribute("quantita");
        float prezzo = (float) request.getSession().getAttribute("prezzo");

        Prodotto pr = new Prodotto();
        ProdottoDAO prDAO = new ProdottoDAO();
        pr = prDAO.doRetrieveById(request.getParameter("id"));
        carrello.remove(pr);
        quantita--;
        prezzo-=pr.getPrezzo();
        request.getSession().setAttribute("carrello",carrello);
        request.getSession().setAttribute("quantita", quantita);
        request.getSession().setAttribute("prezzo", prezzo);
        RequestDispatcher dispatcher = request.getRequestDispatcher("Carrello.jsp");
        dispatcher.forward(request, response);
    }
}
