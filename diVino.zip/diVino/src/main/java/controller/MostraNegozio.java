package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.Prodotto;
import model.ProdottoDAO;

import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "MostraNegozio", value = "/MostraNegozio")
public class MostraNegozio extends HttpServlet {
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ProdottoDAO prodottoDAO = new ProdottoDAO();
        ArrayList<Prodotto> prodotto = (ArrayList<Prodotto>) prodottoDAO.doRetrieveAllProduct();
        request.getSession().setAttribute("listaProdotti", prodotto);
        RequestDispatcher dispatcher = request.getRequestDispatcher("VisualizzaNegozio.jsp");
        dispatcher.forward(request, response);

    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     doGet(request, response);
    }
}
