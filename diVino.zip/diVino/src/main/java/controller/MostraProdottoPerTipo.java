package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.Prodotto;
import model.ProdottoDAO;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

@WebServlet(name = "MostraProdottoPerTipo", value = "/MostraProdottoPerTipo")
public class MostraProdottoPerTipo extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      String tipo= request.getParameter("tipo");
      ProdottoDAO prodottoDAO = new ProdottoDAO();
        ArrayList<Prodotto> prodotto = prodottoDAO.doRetrieveByTipo(tipo);

     /*   PrintWriter output = response.getWriter();

        for(Prodotto p: prodotto)
        {
            output.println(p.getNome());
        }*/
        request.setAttribute("listaProdotti", prodotto);
      /*   RequestDispatcher dispatcher = request.getRequestDispatcher("VisualizzaNegozio.jsp");
        dispatcher.forward(request, response); */

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
