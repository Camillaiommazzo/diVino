package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.ArticoloCarrello;
import model.ArticoloCarrelloDAO;
import model.Utente;

import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "AggiungiAlCarrello", value = "/AggiungiAlCarrello")
public class AggiungiAlCarrello extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ArticoloCarrello prodotto = new ArticoloCarrello();
        prodotto.setPrezzoUnita(Float.parseFloat(request.getParameter("prezzoUnita")));
        prodotto.setCodiceUtente(0);
        prodotto.setNomeUtente(null);
        prodotto.setCodProdotto(0);
        prodotto.setQuantitaP(1);

        HttpSession session = request.getSession();

        //AGGIUNGERE LA GESTIONE SE L'UTENTE NON E' LOGGATO

        if(session.getAttribute("utenteSessione") !=null) {
            Utente user = (Utente) session.getAttribute("utenteSessione");
            prodotto.setCodiceUtente(user.getCodice());
            ArticoloCarrelloDAO dao = new ArticoloCarrelloDAO();
            ArrayList<ArticoloCarrello> temp = (ArrayList<ArticoloCarrello>) dao.doRetrieveShoppingCart(user.getCodice(), user.getNomeUtente());
            for (ArticoloCarrello x:temp ) {
               if( x.getCodProdotto()== prodotto.getCodProdotto()&& x.getNomeUtente()==prodotto.getNomeUtente()&& x.getCodiceUtente()== prodotto.getCodiceUtente()) {
                   int quantita = prodotto.getQuantitaP() + x.getQuantitaP();
                   prodotto.setQuantitaP(quantita);
                   dao.doDelete(prodotto.getId());
               }
            }
            dao.doSave(prodotto);
        }
            RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
