package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.Prodotto;
import model.ProdottoDAO;

import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "AggiungiAlCarrello", value = "/AggiungiAlCarrello")
public class AggiungiAlCarrello extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ArrayList<Prodotto> carrello = (ArrayList<Prodotto>) request.getSession().getAttribute("carrello");
        int quantita;
        if(request.getSession().getAttribute("quantita")==null) {
            quantita = 0;
        } else {
            quantita = (int) request.getSession().getAttribute("quantita");
        }
        float prezzo;
        if(request.getSession().getAttribute("prezzo")==null) {
            prezzo = 0;
        } else {
            prezzo = (float) request.getSession().getAttribute("prezzo");
        }
        if(carrello==null) {
            carrello = new ArrayList<>();
            request.getSession().setAttribute("carrello",carrello);
        }

        Prodotto pr = new Prodotto();
            ProdottoDAO prDAO = new ProdottoDAO();
            pr = prDAO.doRetrieveById(request.getParameter("id"));
            carrello.add(pr);
            quantita++;
            prezzo+= pr.getPrezzo();
            request.getSession().setAttribute("quantita", quantita);
        request.getSession().setAttribute("prezzo", prezzo);
            RequestDispatcher dispatcher = request.getRequestDispatcher("VisualizzaNegozio.jsp");
            dispatcher.forward(request, response);
    }
}
