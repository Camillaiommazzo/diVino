package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.Prodotto;
import model.ProdottoDAO;

import java.io.IOException;

@WebServlet(name = "Insert", value = "/Insert")
public class Insert extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String cod = request.getParameter("cod");
        String nome = request.getParameter("nome");
        float prezzo = Float.parseFloat(request.getParameter("prezzo"));
        String link_immagine = request.getParameter("link_immagine");
        String descrizione = request.getParameter("descrizione");


        ProdottoDAO service = new ProdottoDAO();
        service.doSave(new Prodotto(cod,nome, prezzo,link_immagine, descrizione));
        String address = "/WEB-INF/index.html";

        RequestDispatcher  dispatcher = request.getRequestDispatcher(address);
        dispatcher.forward(request, response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
