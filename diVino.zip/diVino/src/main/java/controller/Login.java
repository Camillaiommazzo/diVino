package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.Utente;
import model.UtenteDAO;

import java.io.IOException;

@WebServlet(name = "Login", value = "/Login")
public class Login extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
          //  boolean log=false;
            String resp="/index.jsp";
            String username = request.getParameter("nome_utente");
            String password = request.getParameter("password");
            UtenteDAO u = new UtenteDAO();
            Utente utente = u.doRetrieveByUsernamePassword(username, password);
            HttpSession session = request.getSession();

        if(utente==null)
        {
            resp="Login.jsp";
          //  log=true;
        }
        else
            session.setAttribute("utenteSessione",utente);

      //  request.setAttribute("logError",log);
        response.sendRedirect("index.jsp");

    }
}
