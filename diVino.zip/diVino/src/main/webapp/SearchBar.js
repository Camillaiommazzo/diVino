$(document).ready(function() {

    $("#search").keyup(function () {

        $.ajax({
            url: '/Cerca',
            dataType: 'html',
            type: 'get',
            data: 'value=' + $("#search").val(),
            success: function (result) {
                $("#search").html(result);
            },
            error: function (result) {
                $("#div").html("Error.");
            }
        });
    });
})