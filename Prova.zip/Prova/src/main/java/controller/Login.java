package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Utente;
import model.UtenteDAO;

import java.io.IOException;

@WebServlet(name = "Login", value = "/Login")
public class Login extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
          //  boolean log=false;
            String resp="/index.jsp";
            String username = request.getParameter("nome_utente");
            String password = request.getParameter("password");
            UtenteDAO u = new UtenteDAO();
            Utente utente = u.doRetrieveByUsernamePassword(username, password);
            HttpSession session = request.getSession();

        if(utente==null)
        {
            resp="Login.jsp";
            request.setAttribute("logError","1");
          //  log=true;
        }
        else {
            session.setAttribute("utenteSessione", utente);
            request.setAttribute("logError", "0");
        }
      //  request.setAttribute("logError",log);
        RequestDispatcher dispatcher = request.getRequestDispatcher(resp);
        dispatcher.forward(request,response);

    }
}
