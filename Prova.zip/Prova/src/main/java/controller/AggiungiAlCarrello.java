package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Prodotto;
import model.ProdottoDAO;

import java.io.IOException;
import java.util.ArrayList;


@WebServlet(name = "AggiungiAlCarrello", value = "/AggiungiAlCarrello")
public class AggiungiAlCarrello extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ArrayList<Prodotto> carrello = (ArrayList<Prodotto>) request.getSession().getAttribute("carrello");
        int quantita;
        float prezzo;
        if(request.getSession().getAttribute("quantita")==null) {
            quantita = 0;
            prezzo = 0;
        } else {
            quantita = (int) request.getSession().getAttribute("quantita");
        }
        if(request.getSession().getAttribute("prezzo")==null) {
            prezzo = 0.0F;
        } else {
            prezzo = (float) request.getSession().getAttribute("prezzo");
        }
        if(carrello==null) {
            carrello = new ArrayList<>();
            request.getSession().setAttribute("carrello",carrello);
        }

        Prodotto pr = new Prodotto();
            ProdottoDAO prDAO = new ProdottoDAO();
            pr = prDAO.doRetrieveById(request.getParameter("id"));
            carrello.add(pr);
            quantita++;
            prezzo+= pr.getPrezzo();
            request.getSession().setAttribute("quantita", quantita);
        request.getSession().setAttribute("prezzo", prezzo);
            RequestDispatcher dispatcher = request.getRequestDispatcher("VisualizzaNegozio.jsp");
            dispatcher.forward(request, response);
    }
}
