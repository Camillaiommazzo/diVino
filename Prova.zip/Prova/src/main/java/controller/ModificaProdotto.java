package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.Prodotto;
import model.ProdottoDAO;

import java.io.IOException;

@WebServlet(name = "ModificaProdotto", value = "/ModificaProdotto")
public class ModificaProdotto extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Prodotto x = new Prodotto();
        ProdottoDAO y = new ProdottoDAO();
        x.setCod(Integer.parseInt(request.getParameter("cod")));
        x.setNome(request.getParameter("nome"));
        x.setPrezzo(Float.parseFloat(request.getParameter("prezzo")));
        x.setTipo(request.getParameter("tipo"));
        x.setLink_immagine(request.getParameter("immagine"));
        x.setDescrizione(request.getParameter("descrizione"));
        y.doUpdateInfo(x);
        RequestDispatcher dispatcher = request.getRequestDispatcher("Magazzino.jsp");
        dispatcher.forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
