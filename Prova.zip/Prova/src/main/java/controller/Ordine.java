package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

@WebServlet(name = "Ordine", value = "/Ordine")
public class Ordine extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        CarrelloDao cDAO = new CarrelloDao();
        ArticoloCarrelloDAO aDAO = new ArticoloCarrelloDAO();
        Utente u = (Utente) request.getSession().getAttribute("utenteSessione");
        ArrayList<Carrello> ordine = (ArrayList<Carrello>) cDAO.doRetrieveByNomeUtente(u.getNomeUtente());
        request.getSession().setAttribute("ordine", ordine);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
