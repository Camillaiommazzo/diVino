package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.ConPool;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@WebServlet(name = "Cerca", value = "/Cerca")
public class Cerca extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        Connection R=null;
        ResultSet rs;

       /* if(request.getParameter("cin")!=null){
            req+= " and cin like upper('" + request.getParameter("cin") + "%')";
        } */

        try {
            R= ConPool.getConnection();
            PreparedStatement req=R.prepareStatement("select * from prodotto where nome LIKE %{?}%");
            req.setString(1, request.getParameter("value"));
            rs = req.executeQuery();
            if (rs.next() == false) {
                out.print("empty");
            } else {
                out.print("<table>");
                do {
                    out.print("<tr><td>" + rs.getObject(1) + "</td><td>" + rs.getObject(2) + "</td><td>" + rs.getObject(3) + "</td><td>" + rs.getObject(4) + "</td></tr>");
                } while (rs.next());
                out.print("</table>");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
