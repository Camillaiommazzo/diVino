package controller;

import com.mysql.cj.Session;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.Utente;
import model.UtenteDAO;

import java.io.IOException;

@WebServlet(name = "CreaSessione", value = "/CreaSessione")
public class CreaSessione extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Utente u = (Utente) request.getSession().getAttribute("utenteSessione");
        UtenteDAO uDAO = new UtenteDAO();
        String nomeUtente = u.getNomeUtente();
        u = uDAO.doRetrieveUsersByNomeUtente(nomeUtente);
        request.getSession().setAttribute("utenteSessione", u);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
