package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Prodotto;
import model.ProdottoDAO;

import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "MostraProdottoPerTipo", value = "/MostraProdottoPerTipo")
public class MostraProdottoPerTipo extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      String tipo= request.getParameter("tipo");
      ProdottoDAO prodottoDAO = new ProdottoDAO();
        ArrayList<Prodotto> prodotto = prodottoDAO.doRetrieveByTipo(tipo);

     /*   PrintWriter output = response.getWriter();

        for(Prodotto p: prodotto)
        {
            output.println(p.getNome());
        }*/
        request.setAttribute("listaProdotti", prodotto);
      /*   RequestDispatcher dispatcher = request.getRequestDispatcher("VisualizzaNegozio.jsp");
        dispatcher.forward(request, response); */

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
