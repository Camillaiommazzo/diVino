package controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Prodotto;

import java.io.IOException;
import java.util.ArrayList;

@WebServlet(name = "SvuotaCarrello", value = "/SvuotaCarrello")
public class SvuotaCarrello extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request,response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ArrayList<Prodotto> carrello = (ArrayList<Prodotto>) request.getSession().getAttribute("carrello");
        carrello.clear();
        request.getSession().setAttribute("carrello",null);
        request.getSession().setAttribute("quantita", 0);
        request.getSession().setAttribute("prezzo", 0.0F);

    }
    }

