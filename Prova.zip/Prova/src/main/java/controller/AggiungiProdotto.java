package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import model.Prodotto;
import model.ProdottoDAO;

import java.io.IOException;

@WebServlet(name = "AggiungiProdotto", value = "/AggiungiProdotto")
public class AggiungiProdotto extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Prodotto p=new Prodotto();
        ProdottoDAO pDAO=new ProdottoDAO();
        p.setNome(request.getParameter("nome"));
        p.setTipo(request.getParameter("tipo"));
        p.setPrezzo(Float.parseFloat(request.getParameter("prezzo")));
        p.setLink_immagine(request.getParameter("immagine"));
        p.setDescrizione(request.getParameter("descrizione"));
        pDAO.doSave(p);
        RequestDispatcher dispatcher = request.getRequestDispatcher("Magazzino.jsp");
        dispatcher.forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
