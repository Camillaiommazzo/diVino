package model;

public class ArticoloCarrello {

    private String  nomeUtente;
    private float prezzoUnita;
    private int codiceUtente, id, codProdotto;

    public String getNomeUtente() {
        return nomeUtente;
    }

    public void setNomeUtente(String nomeUtente) {
        this.nomeUtente = nomeUtente;
    }

    public float getPrezzoUnita() {
        return prezzoUnita;
    }

    public void setPrezzoUnita(float prezzoUnita) {
        this.prezzoUnita = prezzoUnita;
    }

    public int getCodiceUtente() {
        return codiceUtente;
    }

    public void setCodiceUtente(int codiceUtente) {
        this.codiceUtente = codiceUtente;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCodProdotto() {
        return codProdotto;
    }

    public void setCodProdotto(int codProdotto) {
        this.codProdotto = codProdotto;
    }

  }
