package model;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProdottoDAO
{
    public List<Prodotto> doRetrieveAllProduct() {
        List<Prodotto> list = new ArrayList<Prodotto>();
        try (Connection con = ConPool.getConnection())
        {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM prodotto");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Prodotto p = new Prodotto();
                p.setCod((rs.getInt(1)));
                p.setNome(rs.getString(2));
                p.setPrezzo(rs.getFloat(3));
                p.setTipo(rs.getString(4));
                p.setLink_immagine(rs.getString(5));
                p.setDescrizione(rs.getString(6));
                list.add(p);
            }
            return list;
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }


    public Prodotto doRetrieveById(String cod) {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps =
                    con.prepareStatement("SELECT cod, nome, prezzo,tipo,link_immagine, descrizione FROM prodotto WHERE cod=?");
             ps.setString(1, cod);
             ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Prodotto p = new Prodotto();
                p.setCod((rs.getInt(1)));
                p.setNome(rs.getString(2));
                p.setPrezzo(rs.getFloat(3));
                p.setTipo(rs.getString(4));
                p.setLink_immagine(rs.getString(5));
                p.setDescrizione(rs.getString(6));
                return p;
            }
            return null;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public void doSave(Prodotto prodotto) {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO prodotto ( nome, prezzo,tipo,link_immagine, descrizione) VALUES(?,?,?,?,?)"
                    //            , Statement.RETURN_GENERATED_KEYS                   // questo codice è utile solo se si vuole restituire il bean customer completo di id
            );                                                            // in questo caso restituiamo  void per cui è inutile
            ps.setString(1, prodotto.getNome());
            ps.setFloat(2, prodotto.getPrezzo());
            ps.setString(3, prodotto.getTipo());
            ps.setString(4, prodotto.getLink_immagine());
            ps.setString(5, prodotto.getDescrizione());
            if (ps.executeUpdate() != 1) {
                throw new RuntimeException("INSERT error.");
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
        public void doDelete(String cod) {
            try(Connection con = ConPool.getConnection()) {
                PreparedStatement ps = con.prepareStatement("" +
                        "DELETE FROM prodotto WHERE cod =?", Statement.RETURN_GENERATED_KEYS);
                ps.setString(1, cod);
                if (ps.executeUpdate() != 1) {
                    throw new RuntimeException("INSERT error.");
                }
            } catch (SQLException e) {
                throw  new RuntimeException(e);
            }
        }

    public void doUpdateInfo(Prodotto temp )
    {
        try (Connection con = ConPool.getConnection())
        {
            PreparedStatement ps = con.prepareStatement("UPDATE prodotto SET nome=?,prezzo=?,tipo= ?, " +
                            "link_immagine=?, descrizione=? WHERE cod=? ",
                    Statement.RETURN_GENERATED_KEYS);

            ps.setString(1, temp.getNome());
            ps.setFloat(2, temp.getPrezzo());
            ps.setString(3, temp.getTipo());
            ps.setString(4, temp.getLink_immagine());
            ps.setString(5, temp.getDescrizione());
            ps.setInt(6, temp.getCod());
            ps.executeUpdate();

        } catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
    }


    public void doUpdatePrice(Prodotto temp ) {
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps = con.prepareStatement("UPDATE prodotto SET prezzo=?, " +
                            " WHERE cod=? ",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setFloat(1, temp.getPrezzo());
            ps.setInt(2, temp.getCod());
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public ArrayList<Prodotto> doRetrieveByTipo(String tipo) {
        ArrayList<Prodotto> list = new ArrayList<Prodotto>();
        try (Connection con = ConPool.getConnection())
        {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM prodotto WHERE tipo=?");
            ps.setString(1, tipo);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Prodotto p = new Prodotto();
                p.setCod((rs.getInt(1)));
                p.setNome(rs.getString(2));
                p.setPrezzo(rs.getFloat(3));
                p.setTipo(rs.getString(4));
                p.setLink_immagine(rs.getString(5));
                p.setDescrizione(rs.getString(6));
                list.add(p);
            }
            return list;
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public ArrayList<Prodotto> doRetrieveByNome(String nome) {
        ArrayList<Prodotto> list = new ArrayList<Prodotto>();
        try (Connection con = ConPool.getConnection())
        {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM prodotto WHERE nome=?");
            ps.setString(1, nome);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Prodotto p = new Prodotto();
                p.setCod((rs.getInt(1)));
                p.setNome(rs.getString(2));
                p.setPrezzo(rs.getFloat(3));
                p.setTipo(rs.getString(4));
                p.setLink_immagine(rs.getString(5));
                p.setDescrizione(rs.getString(6));
                list.add(p);
            }
            return list;
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public ArrayList<Prodotto> doRetrieveByLinkImmagine(String link_immagine) {
        ArrayList<Prodotto> list = new ArrayList<Prodotto>();
        try (Connection con = ConPool.getConnection())
        {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM prodotto WHERE link_immagine=?");
            ps.setString(1, link_immagine);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Prodotto p = new Prodotto();
                p.setCod((rs.getInt(1)));
                p.setNome(rs.getString(2));
                p.setPrezzo(rs.getFloat(3));
                p.setTipo(rs.getString(4));
                p.setLink_immagine(rs.getString(5));
                p.setDescrizione(rs.getString(6));
                list.add(p);
            }
            return list;
        }
        catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}

