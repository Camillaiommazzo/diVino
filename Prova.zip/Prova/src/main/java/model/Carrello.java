package model;

import javax.xml.crypto.Data;
import java.util.ArrayList;

import java.util.Date;
import java.util.GregorianCalendar;

public class Carrello {
   /* public int getCounter() {
        return counter;
    }

    public void setCounter(int counter) {
        this.counter = counter;
    }

    private int counter= 0;*/
    private String nomeU;
    private float totale;
    private java.sql.Date dataC;
    private int quantita, codiceU;

    private ArrayList<ArticoloCarrello> articoli = new ArrayList<ArticoloCarrello>();

    public ArrayList<ArticoloCarrello> getArticoli() {
        return articoli;
    }

    public void setArticoli(ArrayList<ArticoloCarrello> articoli) {
        this.articoli = articoli;
    }

    public String getNomeU() {
        return nomeU;
    }

    public void setNomeU(String nomeU) {
        this.nomeU = nomeU;
    }

    public float getTotale() {
        return totale;
    }

    public void setTotale(float totale) {
        this.totale = totale;
    }

    public Date getDataC() {
        return dataC;
    }

    public void setDataC(java.sql.Date dataC) {
        this.dataC = dataC;
    }

    public int getQuantita() {
        return quantita;
    }

    public void setQuantita(int quantita) {
        this.quantita = quantita;
    }

    public int getCodiceU() {
        return codiceU;
    }

    public void setCodiceU(int codiceU) {
        this.codiceU = codiceU;
    }

}
