package model;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UtenteDAO {
    public List<Utente> doRetrieveAllUsers() {
        List<Utente> list = new ArrayList<Utente>();
        try (Connection con = ConPool.getConnection()){
            PreparedStatement ps = con.prepareStatement("SELECT * FROM utente");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Utente p = new Utente();
                p.setCodice(rs.getInt(1));
                p.setNomeUtente(rs.getString(2));
                p.setNome(rs.getString(3));
                p.setCognome(rs.getString(4));
                p.setVia(rs.getString(5));
                p.setCap(rs.getInt(6));
                p.setTelefono(rs.getString(7));
                p.setPassword(rs.getString(8));
                p.setCivico(rs.getInt(9));
                p.setAmministratore(rs.getBoolean(10));
                p.setCitta(rs.getString(11));
                list.add(p);
            }
            return list;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Utente doRetrieveUsersByNomeUtente (String nomeUtente) throws NumberFormatException {
        Utente user = new Utente();
        try (Connection con = ConPool.getConnection()) {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM utente WHERE nomeUtente=?");
            ps.setString(1, (nomeUtente));
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                user.setNomeUtente(rs.getString(2));
                user.setNome(rs.getString(3));
                user.setCognome(rs.getString(4));
                user.setVia(rs.getString(5));
                user.setCap(rs.getInt(6));
                user.setTelefono(rs.getString(7));
                user.setPassword(rs.getString(8));
                user.setCivico(rs.getInt(9));
                user.setAmministratore(rs.getBoolean(10));
                user.setCitta(rs.getString(11));
            }
            return user;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Utente doRetrieveByUsernamePassword(String nomeUtente, String password) {
        try (Connection con = ConPool.getConnection()){
            PreparedStatement ps = con.prepareStatement("SELECT * FROM utente WHERE nomeUtente = ? and passwordUtente=?");
            ps.setString(1, nomeUtente);
            ps.setString(2, password);
            Utente p = new Utente();
            ResultSet rs = ps.executeQuery();
            if(rs.next()) {
                p.setCodice(rs.getInt(1));
                p.setNomeUtente(rs.getString(2));
                p.setNome(rs.getString(3));
                p.setCognome(rs.getString(4));
                p.setVia(rs.getString(5));
                p.setCap(rs.getInt(6));
                p.setTelefono(rs.getString(7));
                p.setPassword(rs.getString(8));
                p.setCivico(rs.getInt(9));
                p.setAmministratore(rs.getBoolean(10));
                p.setCitta(rs.getString(11));
            } else p=null;
            return p;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void doSave(Utente customer)
    {
        try (Connection con = ConPool.getConnection()){
            PreparedStatement ps = con.prepareStatement("INSERT INTO utente (codice,nomeUtente, nome, cognome, via, cap,telefono,passwordUtente, civico, amministratore, citta) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, customer.getCodice());
            ps.setString(2, customer.getNomeUtente());
            ps.setString(3, customer.getNome());
            ps.setString(4, customer.getCognome());
            ps.setString(5,customer.getVia());
            ps.setInt(6, customer.getCap());
            ps.setString(7, customer.getTelefono());
            ps.setString(8, customer.getPassword());
            ps.setInt(9, customer.getCivico());
            ps.setBoolean(10, customer.isAmministratore());
            ps.setString(11, customer.getCitta());
            if (ps.executeUpdate() !=1) {
                throw new RuntimeException("INSERT error.");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void doDelete(String nomeUtente)
    {
        try (Connection con = ConPool.getConnection())
        {
            PreparedStatement ps = con.prepareStatement
                    ("Delete FROM utente WHERE nomeUtente=?",
                            Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, nomeUtente);
            if (ps.executeUpdate() != 1)
            {
                throw new RuntimeException("INSERT error.");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void doUpdateUserInfo(Utente temp )
    {
        try (Connection con = ConPool.getConnection())
        {
            PreparedStatement ps = con.prepareStatement("UPDATE utente SET nome=?,cognome=?,via=?,  passwordUtente=?, citta=?, telefono=?, cap=?, civico=? WHERE nomeUtente=? ",
                    Statement.RETURN_GENERATED_KEYS);

            ps.setString(1, temp.getNome());
            ps.setString(2, temp.getCognome());
            ps.setString(3, temp.getVia());
            ps.setString(4, temp.getPassword());
            ps.setString(5, temp.getCitta());
            ps.setString(6, temp.getTelefono());
            ps.setInt(7,temp.getCap());
            ps.setInt(8,temp.getCivico());
            ps.setString(9, temp.getNomeUtente());
            ps.executeUpdate();

        } catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
    }
/*
    public void doUpdateUsername(Utente temp)
    {
        try (Connection con = ConPool.getConnection())
        {
            PreparedStatement ps = con.prepareStatement("UPDATE utente SET nome_utente=? WHERE codice=? ",
                    Statement.RETURN_GENERATED_KEYS);

            ps.setString(1, temp.getNomeUtente());
            ps.setInt(2, temp.getCodice());
            ps.executeUpdate();

        } catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
    } */

    public void doUpdatePassword(Utente temp)
    {
        try (Connection con = ConPool.getConnection())
        {
            PreparedStatement ps = con.prepareStatement("UPDATE utente SET passwordUtente=? WHERE codice=? ",
                    Statement.RETURN_GENERATED_KEYS);

            ps.setString(1, temp.getPassword());
            ps.setInt(2, temp.getCodice());
            ps.executeUpdate();

        } catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
    }

    public void doAddAdmin(String nomeUtente)
    {
        try (Connection con = ConPool.getConnection())
        {
            PreparedStatement ps = con.prepareStatement("UPDATE utente SET amministratore=true WHERE nomeUtente=? ",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, nomeUtente);
            ps.executeUpdate();

        } catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
    }

    public void doRemoveAdmin(String nomeUtente)
    {
        try (Connection con = ConPool.getConnection())
        {
            PreparedStatement ps = con.prepareStatement("UPDATE utente SET amministratore=false WHERE nomeUtente=? ",
                    Statement.RETURN_GENERATED_KEYS);

            ps.setString(1, nomeUtente);
            ps.executeUpdate();

        } catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
    }



}
